// pages/register/register.js
const db = wx.cloud.database() 
const volunteer =  db.collection('user')
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        buttonText:"完成注册",
        name:app.globalData.name,
        school:app.globalData.school,
        age:app.globalData.age,
        sex:app.globalData.sex,
        phone:app.globalData.phone,
        email:app.globalData.email,
        biography:app.globalData.biography,
        address:app.globalData.address,
        area:app.globalData.address,
        items: [
            { name: 'man', value: '男', checked: false },
            { name: 'women', value: '女',checked:false},
          ],
    },
    radioChange: function (e) {
        if (e.detail.value == "women") {
          this.setData({ sex: "女" })
        }
        else { this.setData({ sex: "男"}) }
      },    
    choosearea(){
        var that = this
        wx.chooseLocation({
            success(e){
                console.log("地址信息",e.name,e.address)
                that.setData({
                    area:e.name,
                    address:e.name+"("+e.address+")"
                })
            }
        })
    },
    showtost:function(text){
        wx.showToast({
            title: text,
            icon: 'none',
            duration: 1500,
            mask: false,
          })
    },
    submit(e){
        // console.log("openid",wx.getStorageSync("openid"))
        //添加一个data数据到数据库中
        var that=this
        if(e.detail.value.name==""){
            this.showtost("请输入姓名")
        }else if(e.detail.value.phone.length != 11){
            this.showtost("请输入正确的手机号码")
        }else{
            if (wx.getStorageSync("openid")) {
                volunteer.where({_openid:wx.getStorageSync("openid")}).get().then(res =>{   
                    if(res.data.length==0){
                        volunteer.add({
                            data:{
                                // openid:wx.getStorageSync("openid"),
                                name: e.detail.value.name,
                                school:e.detail.value.school,
                                age: e.detail.value.age,
                                sex: that.data.sex,
                                phone:e.detail.value.phone,
                                email:e.detail.value.email,
                                address:that.data.address,
                                biography:e.detail.value.biography,
                                score:0,
                                credScore:100,
                                manager:false
                            }
                        })
                        app.globalData.name= e.detail.value.name
                        app.globalData.school= e.detail.value.school
                        app.globalData.age= e.detail.value.age
                        app.globalData.sex= that.data.sex
                        app.globalData.phone=e.detail.value.phone
                        app.globalData.email=e.detail.value.email
                        app.globalData.address=that.data.address
                        app.globalData.biography=e.detail.value.biography
                        app.globalData.manager=false
                        app.globalData.score=0
                        app.globalData.credScore=100
                        this.showtost("注册成功")
                        wx.switchTab({
                            url: '/pages/index/index',
                        })
                    }else{
                        volunteer.where({_openid:wx.getStorageSync("openid")
                        }).update({
                            data:{
                                name: e.detail.value.name,
                                school:e.detail.value.school,
                                age: e.detail.value.age,
                                sex: that.data.sex,
                                phone:e.detail.value.phone,
                                email:e.detail.value.email,
                                address:that.data.address,
                                biography:e.detail.value.biography,
                            },
                        success: res => {
                            this.showtost("信息修改成功")
                            app.globalData.name= e.detail.value.name
                            app.globalData.school= e.detail.value.school
                            app.globalData.age= e.detail.value.age
                            app.globalData.sex= that.data.sex
                            app.globalData.phone=e.detail.value.phone
                            app.globalData.email=e.detail.value.email
                            app.globalData.address=that.data.address
                            app.globalData.biography=e.detail.value.biography
                        },
                        fail: err => {
                        this.showtost("上传失败")
                        console.error('[数据库] [删除记录] 失败：', err)
                        }
                        })
                        }
                   }).catch(err =>{
                      console.log('查询请求失败',err)
                   })
            }else{
                console.log("没有openid")
            }
        }
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        if(app.globalData.name.length!=""){
            this.setData({buttonText:"完成修改"})
        }
       this.setData({
        name:app.globalData.name,
        school:app.globalData.school,
        age:app.globalData.age,
        sex:app.globalData.sex,
        phone:app.globalData.phone,
        email:app.globalData.email,
        biography:app.globalData.biography,
        address:app.globalData.address,
        area:app.globalData.address,
        items: [
            { name: 'man', value: '男',checked: app.globalData.sex=="男" },
            { name: 'women', value: '女',checked: app.globalData.sex=="女"},
          ],
       })
       console.log(this.data)
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})