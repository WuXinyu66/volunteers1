const app = getApp()
const activity = wx.cloud.database().collection('activity')
Page({
  data: {

  },
  onLoad() {
     var that=this
         activity.orderBy('createDate','desc')
        .get().then(res=>{
              console.log(res.data)
                that.setData({
                       activities:res.data
                })
                console.log("activities", this.data.activities)
                for(let i=0;i<res.data.length;i++){
                    let url= "activities[" + i + "].url"
                    let  activity= JSON.stringify(res.data[i]);
                    that.setData({
                        [url]:'/pages/activity_detail/activity_detail?activity='+encodeURIComponent(activity)
                    })
                }
    
            })
            .catch(err=>{
            console.log('升序失败',err)
            })
  },
})
