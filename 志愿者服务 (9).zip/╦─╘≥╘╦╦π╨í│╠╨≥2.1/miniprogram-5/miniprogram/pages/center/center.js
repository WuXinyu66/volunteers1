// pages/center/center.js
const app = getApp()
const user = wx.cloud.database().collection('user')
var openid = wx.getStorageSync("openid");
Page({
  data:{
  },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
    
      },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        /**
         * 获取用户信息
         */
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
      
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
     onLoad: function (options){
      this.setData({ 
      score:app.globalData.score,
      credScore:app.globalData.credScore,
      manager:wx.getStorageSync('manager')
    })
      console.log("openid："+openid);
      // 获取用户信息
      if( app.globalData.userInfo==null){
        this.login()
      }
        var that = this
          this.setData({
            username:app.globalData.userInfo.nickName,
            face:app.globalData.userInfo.avatarUrl
          })
      // 设置延时
      setTimeout(function () {
        that.setData({
          myOpenid: openid
        })
      },2000)
      
    },
    login: function () {
      var that = this;
        wx.showModal({
          title: '温馨提示',
          content: '正在请求获取您的个人信息，以后续方便使用本程序！',
          showCancel:false,
          success(res) {
            if (res.confirm) {
              wx.getUserProfile({
                desc: "获取你的昵称、头像、地区及性别",
                success: res => {
                  app.globalData.hasUserInfo = true;
                  app.globalData.userInfo=res.userInfo
                  app.globalData.openid=res.openid
                  wx.setStorageSync('hadAuthed', true)
                  wx.getStorageSync('hadAuthed')
                  that.onLoad()
                    //这里可以发起获取token的请求
                  // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
                },
                fail: res => {
                  //拒绝授权
                  that.showErrorModal();
                  return;
                }
              })
            } else if (res.cancel) {
              //拒绝授权 showErrorModal是自定义的提示
              that.showErrorModal();
              return;
            }
          }
        })
      },
      showErrorModal:function(){
        wx.showModal({
          title: '温馨提示',
          content: '拒绝授权将无法使用本程序',
          showCancel:false,
        })
      }
     
})
