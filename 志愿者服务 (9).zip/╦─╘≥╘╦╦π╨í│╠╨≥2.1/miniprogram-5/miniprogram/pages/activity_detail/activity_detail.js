const app = getApp()
const user = wx.cloud.database().collection('user')
const activity = wx.cloud.database().collection('activity')
const _ = wx.cloud.database().command
var openid = wx.getStorageSync("openid");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ellipsis:true,//默认收起
    apply:false
  },
   signup(){
    this.setData({
      apply:true,
    })
    console.log(this.data.activity_detail._id)
    app.globalData.applylist=app.globalData.applylist.concat(this.data.activity_detail._id)
    let that=this
    activity.where({
      _id: that.data.activity_detail._id
    }).get().then(res => {
      let subject = res.data[0]
       try{
        console.log(subject.userlist)
        let len=res.data[0].userlist.length
        var value = 'userlist.'+len
        activity.where({_id:that.data.activity_detail._id
        }).update({ 
             data:{
              [value]:openid
          },
         }).then(res=>{
                console.log("成功更新数据库",res);
                wx.showToast({
                  title: "报名成功",
                  icon: 'none',
                  duration: 1500,
                  mask: false,
                })
              })
             //错误时执行
             .catch(err=>{
              this.setData({apply:false})
              wx.showToast({
                title: "报名失败",
                icon: 'none',
                duration: 1500,
                mask: false,
              })
           })
        
       }catch{
        activity.doc(that.data.activity_detail._id)
        .update({ 
           data:{
            userlist:Array(openid)
        }
       })
        console.log("第一个参与者")
       }
      
    })
    user.where({
      _openid: openid
    }).get().then(res => {
       try{
        let len=res.data[0].actlist.length
        // console.log("len",len)
        var value = 'actlist.'+len
        // console.log(value)
        user.where({_openid:openid
        }).update({ 
             data:{
              [value]:that.data.activity_detail._id
          },
         }).then(res=>{
                console.log("成功更新数据库",res);
              })
             //错误时执行
             .catch(err=>{
              console.log(err);
           })
       }catch{
        user.where({_openid:openid})
        .update({ 
           data:{
            actlist:Array(that.data.activity_detail._id)
        }
       })
        console.log("第一个参与者")
       }
    })
    
  },

  onLoad: function (options) {
    let activity_detail =JSON.parse(decodeURIComponent(options.activity))
    console.log("onload",activity_detail)
    this.setData({
      activity_detail:activity_detail,
      apply:options.apply
  })
  try{
    // console.log(this.data.activity_detail.userlist)
    // console.log(this.data.activity_detail.userlist.indexOf(openid))
    if(this.data.activity_detail.userlist.indexOf(openid)>=0){
      this.setData({apply:true})
  }}catch{
    if(app.globalData.applylist.indexOf(openid)>=0){
      this.setData({apply:true})
    }
  }
    if(app.globalData.applylist.indexOf(this.data.activity_detail._id)>=0||this.data.activity_detail.userlist.indexOf(openid)>=0){
      this.setData({apply:true})
    }
    
    console.log(this.data.activity_detail)
    //创建节点选择器
    var query = wx.createSelectorQuery();
    query.select('#text').boundingClientRect();
    query.exec((res) => {
      res[0].height;
      this.setData({
        height: res[0].height
      })
    })
  },
  /**
   * 收起/展开按钮点击事件
   */
  ellbtn_1: function () {
    this.setData({
      ellipsis: !this.data.ellipsis
    })
  },
  ellbtn_2: function () {
    this.setData({
      ellipsis: !this.data.ellipsis
    })
  },
  onShow:function(){

  }


})
