import dateTimePicker from './dateTimePicker.js'
var result = new Array()
const activity = wx.cloud.database().collection('activity')
const _ = wx.cloud.database().command
const app=getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    files: [],
    typelist: [],
    fileID: [],
    select: true,
    text_area: '',
    returnpath: [],
    openid: "",
    selctedimg:'',
    area:'',
    activity_time: '',
    dateTime: null,
    dateTimeArray: null,
    startYear: new Date().getFullYear(),
    endYear: new Date().getFullYear() + 10,
    swtch:false,
    manager:wx.getStorageSync('manager'),
    apply:false
  },
  changeDateTime(e) {
    this.setData({
      dateTime: e.detail.value
    });
    var arr = this.data.dateTime,
      dateArr = this.data.dateTimeArray;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    
    var activity_time = `${dateArr[0][arr[0]]}-${dateArr[1][arr[1]]}-${dateArr[2][arr[2]]} ${dateArr[3][arr[3]]}:${dateArr[4][arr[4]]}`;
    this.setData({
      dateTimeArray: dateArr,
      dateTime: arr,
      activity_time,
    });
    console.log("活动时间",this.data.activity_time)
  },
  getdata:function(){
   // 获取完整的年月日 时分秒，以及默认显示的数组
  //  var obj = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
   var obj1 = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
   // 精确到分的处理，将数组的秒去掉
  obj1.dateTimeArray.pop();
  obj1.dateTime.pop();
   this.setData({
     dateTime: obj1.dateTime,
     dateTimeArray: obj1.dateTimeArray
   });
  },
  
  submit(e){
    console.log("点击了发布",e)
    console.log(e.detail.value.station)
      activity.add({
        data: {
           station:e.detail.value.station,
           organizer:app.globalData.name,
           address:this.data.area,
           date:this.data.activity_time,
           name:e.detail.value.activity_name,
           detail:e.detail.value.activity_detail,
           phone:e.detail.value.input_phone,
           wxid:e.detail.value.input_wx,
           score:e.detail.value.input_score,
           createDate: wx.cloud.database().serverDate(),
           userlist:new Array("diyigeyonghu"),
           path:this.data.fileID
         },
        success(res){
          wx.showToast({
            title: "发布活动成功",
            icon: 'none',
            duration: 1500,
            mask: false,
          })
        }
       }) 
wx.reLaunch({
  url: '/pages/index/index',
})
console.log('云存储的路径集合' ,this.data.fileID)
  },
  choosearea(){
    var that = this
    wx.chooseLocation({
        success(e){
            console.log("地址信息",e.name,e.address)
            that.setData({
                area:e.name
            })
        }
    })
},
  chooseMedia: function (e) {
      var that = this;
      wx.chooseMedia({
        count:9,
        MediaType: ['image','video','mix'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
        maxDuration:60,
        camera:'back',
        success(res){
          
          res.tempFiles.forEach(function(item){
            console.log(item)
            console.log(item.tempFilePath)
            that.setData({
                files: that.data.files.concat(item.tempFilePath),
                typelist: that.data.typelist.concat(item.tempFilePath.split(".")[1])
              });
              console.log("上传的图片路径",item.tempFilePath)
              

            // wx.uploadFile({
            //   cloudPath:'video/'+item.tempFilepath+'.mp4',
            //   filePath: item.tempFilepath,
            //   name:(new Date()).valueOf(),
            //   formData:{
            //     'type':item.fileType
            //   }
            //   ,
            //   success(res){
            //     console.log('最后的res', res)
            //   }
            // })
          })
        }
      })
    },

  deleteimg: function (e) {
    var files = this.data.files;
    var index = e.currentTarget.dataset.index;
    files.splice(index, 1);
    this.setData({
      files: files
    });
  },
  previewImage: function (e) {
    var id = e.currentTarget.id;
    console.log("id",e.currentTarget.id)
    var imgArr = [];
    var objkeys = Object.keys(this.data.files);
    console.log(this.data.files[0])
    for (var i = 0; i < objkeys.length; i++) {
      imgArr.push(this.data.files[i]);
    }
    wx.previewImage({
      current: id,//当前图片地址
      urls: imgArr
    })
  },
  up_img: function (e) {
    var content = e.detail.value
    var files =this.data.files
    var filetypes =this.data.filetypes
    console.log('files是啥', files)
    if (content.stuff_name == "") {
      wx.showToast({
        title: '请输入活动主题',
        icon: 'none',
        duration: 1500,
        mask: false,
      })
    } else if (content.input_phone == "" && content.input_wx == "") {
      wx.showToast({
        title: '请至少输入一种联系方式',
        icon: 'none',
        duration: 1500,
        mask: false,
      })
    } else if (content.input_phone.length != 0 && content.input_phone.length != 11 && content.input_phone.length != 8) {
      wx.showToast({
        title: '请输入格式正确的手机号码',
        icon: 'none',
        duration: 1500,
        mask: false,
      })
    } else if (content.input_wx.length != 0 && content.input_wx.length < 5 || content.input_wx.length > 11) {
      wx.showToast({
        title: '请输入格式正确的微信号',
        icon: 'none',
        duration: 1500,
        mask: false,
      })
    } else {
      this.setData({
        swtch:true
      })
      var pics = this.data.files;
      var filetypes = this.data.filetypes;
      if (pics.length === 0) {
        this.submit(e);
      } else {
        let timestamp = (new Date()).valueOf()
        var data = {
          //cloudPath:'storage/'+timestamp,
          path: pics,//这里是选取的图片的地址数组
          formData:filetypes,
          e:e
        }
        this.uploadimg(data);
        console.log('data',data)
        console.log('cloudPath',data.cloudPath)
      }
    }
  },
  uploadimg: function (data) {
    // console.log(data)
    var e = data.e
    // var result = new Array();
    var that = this
    var typelist=this.data.typelist,

      i = data.i ? data.i : 0,//当前上传的哪张图片
      success = data.success ? data.success : 0,//上传成功的个数
      fail = data.fail ? data.fail : 0;//上传失败的个数
    let timestamp = (new Date()).valueOf()
    wx.cloud.uploadFile({
      cloudPath: 'storage/'+timestamp+'.'+typelist[i],
      filePath: data.path[i],
      //name: 'file',//这里根据自己的实际情况改
      formData: data.formData,//这里是上传图片时一起上传的数据
      success: (resp) => {
        success++;//图片上传成功，图片上传成功的变量+1
        result.push(resp.data);
        console.log(resp.fileID)
        that.setData({
          fileID: that.data.fileID.concat(resp.fileID)
        })
       ;

        
        // console.log(result);
        // console.log(i);
        //这里可能有BUG，失败也会执行这里,所以这里应该是后台返回过来的状态码为成功时，这里的success才+1
      },
      fail: (res) => {
        fail++;//图片上传失败，图片上传失败的变量+1
        console.log('失败原因',res)
        // console.log('fail:' + i + "fail:" + fail);
      },
      complete: () => {
        // console.log(i);
        i++;//这个图片执行完上传后，开始上传下一张
        if (i == data.path.length) {   //当图片传完时，停止调用          
          console.log('执行完毕');
          console.log('成功：' + success + " 失败：" + fail);
          console.log(result);
          this.submit(e);
          // console.log(e)
        } else {//若图片还没有传完，则继续调用函数
          // console.log(i);
          data.i = i;
          data.success = success;
          data.fail = fail;
          that.uploadimg(data);
        }
        
      }
      
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onLoad: function () {
    if(wx.getStorageSync('manager')==""||wx.getStorageSync('manager')==null){
      wx.reLaunch({
        url: 'pages/post/post',
      })
    }
    console.log("post manager",wx.getStorageSync('manager'))
    this.setData({manager:wx.getStorageSync('manager')})
    this.getdata()
    result = new Array()
    if(!wx.getStorageSync('manager')){
      wx.showModal({
        title: '权限过低',
        content: '只有管理员能发布活动',
        showCancel:false,
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

})