const db = wx.cloud.database() 
const activity =  db.collection('activity')
const user =  db.collection('user')
const openid = wx.getStorageSync("openid");
Page({
  /**
   * 页面的初始数据
   */
  data: {
    activities:[]
  },
  getactivity:function(){
    var that = this
     user.where({_openid:openid}).get()
      .then(res=>{
        for(let i=0;i<res.data[0].actlist.length;i++){
        activity.where({_id:res.data[0].actlist[i]})
        .get().then(res=>{         
            let  activity= JSON.stringify(res.data[0]);
            res.data[0].url='/pages/activity_detail/activity_detail?activity='+encodeURIComponent(activity)+"&apply=true"
            that.setData({
                activities: that.data.activities.concat(res.data[0])
            })
            console.log(that.data.activities)
        }).catch(err=>{
          console.log('失败',err)
          }) 
      }
      })
      .catch(err=>{
      console.log('失败2',err)
      }) 
  },
  onLoad: function (options) {
    this.getactivity()        
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

})