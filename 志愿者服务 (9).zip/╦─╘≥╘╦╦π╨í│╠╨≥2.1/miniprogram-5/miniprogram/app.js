// app.js
App({
  globalData: {
    userInfo: null,
    openid:null,
    applylist:[],
    score:0.0,
    credScore:100.0,
    address:"",
    name: "",
    school:"",
    age: "",
    sex: "",
    phone:"",
    email:"",
    address:"",
    biography:"",
    manager:false,
    actlist:[]
  },
login: function () {
var that = this;
  wx.showModal({
    title: '温馨提示',
    content: '正在请求获取您的个人信息，以后续方便使用本程序！',
    showCancel:false,
    success(res) {
      if (res.confirm) {
        wx.getUserProfile({
          desc: "获取你的昵称、头像、地区及性别",
          success: res => {
            that.globalData.hasUserInfo = true;
            that.globalData.userInfo=res.userInfo
            that.globalData.openid=res.openid
            wx.setStorageSync('hadAuthed', true)
            wx.getStorageSync('hadAuthed')
              //这里可以发起获取token的请求
            // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
          },
          fail: res => {
            //拒绝授权
            that.showErrorModal();
            return;
          }
        })
      } else if (res.cancel) {
        //拒绝授权 showErrorModal是自定义的提示
        that.showErrorModal();
        return;
      }
    }
  })
},
showErrorModal:function(){
  wx.showModal({
    title: '温馨提示',
    content: '拒绝授权将无法使用本程序',
    showCancel:false,
  })
},
onLaunch: function () {
  wx.cloud.init({
      env:'env-0gkg9p1y54cdc0f3'
    })
    this.login()
if(wx.getStorageSync('openid')){
  this.globalData.openid = wx.getStorageSync('openid')
}

if(wx.getStorageSync('userInfo')){
  this.globalData.userInfo = wx.getStorageSync('userInfo')
}
var that = this;
wx.cloud.callFunction({
  name:'getUserOpenid',
  success(res){
    console.log("获取到的openid",res.result.openid)
    that.globalData.openid = res.result.openid
    const user = wx.cloud.database().collection('user')
    if(res.result.openid!=null){
    user.where({_openid:res.result.openid
    }).get().then(d =>{
    console.log('用户数据',d.data)
    try{
      that.globalData.address=d.data[0].address
      that.globalData.name= d.data[0].name
      that.globalData.school= d.data[0].school
      that.globalData.age= d.data[0].age
      that.globalData.sex= d.data[0].sex
      that.globalData.phone=d.data[0].phone
      that.globalData.email=d.data[0].email
      that.globalData.address=d.data[0].address
      that.globalData.biography=d.data[0].biography
      that.globalData.manager=d.data[0].manager
      that.globalData.score=d.data[0].score
      that.globalData.actlist=d.data[0].actlist
      that.globalData.credScore=d.data[0].credScore
      wx.setStorageSync('manager', d.data[0].manager)
      console.log("gesmanager",wx.getStorageSync("manager"))
      console.log("d.data[0].manager",d.data[0].manager)
    }catch{
      console.log("前往注册页面")
      wx.redirectTo({
        url: '/pages/register/register',
      })
    }})
    wx.switchTab({
      url: '/pages/index/index',
    })}else{
      wx.redirectTo({
        url: '/pages/register/register',
      })
      console.log(res.result.openid)
    }
    wx.setStorageSync('openid', res.result.openid)
  }
})
console.log("app manager",this.globalData.manager)
},
})

